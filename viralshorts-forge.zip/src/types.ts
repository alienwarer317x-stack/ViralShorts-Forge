export type VideoFormat = '16:9' | '9:16' | '1:1';

export type FilmAspectGuidance = 
  | 'cinemascope_239' 
  | 'anamorphic_200' 
  | 'academy_185' 
  | 'imax_vertical_916' 
  | 'full_frame_169';

export type SocialFramePreset = 'none' | 'tiktok' | 'youtube_shorts' | 'instagram_reels';

export type CapCutTemplateType = 'velocity_ramp' | 'beat_drop' | 'light_leak' | 'cinematic_mood' | 'glitch_pop';

export interface TimelineTrack {
  id: string;
  name: string;
  type: 'video' | 'audio' | 'text';
  heightPx: number;
  isMuted?: boolean;
  isLocked?: boolean;
}

export interface TimelineClip {
  id: string;
  trackId: string;
  trackType: 'video' | 'audio' | 'text';
  name: string;
  startSec: number;
  durationSec: number;
  trimInSec: number;
  color: string;
  base64?: string;
  mimeType?: string;
  speed?: number;
  volume?: number;
  text?: string;
  fontSize?: number;
  textColor?: string;
  textBgColor?: string;
}

export interface ProjectSettings {
  fps: number;
  resolution: string;
  aspectRatio: VideoFormat;
}

export interface StoryboardScene {
  id: string;
  order: number;
  duration: number;
  title: string;
  storyBeat: string;
  visualDescription: string;
  continuityFromPrevious: string;
  narration: string;
  visualPrompt: string;
  animationPrompt: string;
  caption: string;
  hookKeywords: string[];
  status: 'ready' | 'generating' | 'completed';
}

export interface VideoProject {
  id: string;
  title: string;
  topic: string;
  scenes: StoryboardScene[];
}

export interface CapCutTemplateConfig {
  enabled: boolean;
  templateId: CapCutTemplateType;
  socialFrame: SocialFramePreset;
  beatDropEnabled: boolean;
  kineticZoom: boolean;
  lightLeakEffect: boolean;
  bpmRate: number;
}
