export interface CachedAudioPeaks {
  peaks: Float32Array;
  duration: number;
  sampleRate: number;
}

class AssetCacheService {
  private audioCtx: AudioContext | null = null;
  private audioPeaksCache = new Map<string, CachedAudioPeaks>();
  private videoBlobUrlCache = new Map<string, string>();
  private videoElementPool = new Map<string, HTMLVideoElement>();

  private getAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtx();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  getOrCreateVideoUrl(clipId: string, base64: string, mimeType: string = 'video/mp4'): string {
    if (this.videoBlobUrlCache.has(clipId)) {
      return this.videoBlobUrlCache.get(clipId)!;
    }
    try {
      const byteChars = atob(base64);
      const byteNumbers = new Uint8Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) {
        byteNumbers[i] = byteChars.charCodeAt(i);
      }
      const blob = new Blob([byteNumbers], { type: mimeType });
      const url = URL.createObjectURL(blob);
      this.videoBlobUrlCache.set(clipId, url);
      return url;
    } catch {
      return `data:${mimeType};base64,${base64}`;
    }
  }

  async prewarmVideoElement(clipId: string, base64: string, mimeType: string = 'video/mp4'): Promise<HTMLVideoElement> {
    if (this.videoElementPool.has(clipId)) {
      return this.videoElementPool.get(clipId)!;
    }
    const src = this.getOrCreateVideoUrl(clipId, base64, mimeType);
    const video = document.createElement('video');
    video.src = src;
    video.preload = 'auto';
    video.muted = true;
    video.playsInline = true;
    video.style.position = 'absolute';
    video.style.opacity = '0';
    video.style.pointerEvents = 'none';
    video.style.width = '0';
    video.style.height = '0';
    document.body.appendChild(video);
    this.videoElementPool.set(clipId, video);
    return new Promise((resolve) => {
      const onLoaded = () => {
        video.removeEventListener('loadeddata', onLoaded);
        resolve(video);
      };
      video.addEventListener('loadeddata', onLoaded, { once: true });
      setTimeout(() => resolve(video), 600);
    });
  }

  async precomputeAudioPeaks(cacheKey: string, base64: string, numBuckets: number = 200): Promise<CachedAudioPeaks> {
    if (this.audioPeaksCache.has(cacheKey)) {
      return this.audioPeaksCache.get(cacheKey)!;
    }
    try {
      const ctx = this.getAudioContext();
      const byteChars = atob(base64);
      const byteNumbers = new Uint8Array(byteChars.length);
      for (let i = 0; i < byteChars.length; i++) {
        byteNumbers[i] = byteChars.charCodeAt(i);
      }
      const audioBuffer = await ctx.decodeAudioData(byteNumbers.buffer.slice(0));
      const channelData = audioBuffer.getChannelData(0);
      const step = Math.max(1, Math.floor(channelData.length / numBuckets));
      const peaks = new Float32Array(numBuckets);
      for (let i = 0; i < numBuckets; i++) {
        const start = i * step;
        const end = Math.min(channelData.length, start + step);
        let max = 0;
        for (let j = start; j < end; j++) {
          const val = Math.abs(channelData[j]);
          if (val > max) max = val;
        }
        peaks[i] = Math.min(1.0, max);
      }
      const result: CachedAudioPeaks = {
        peaks,
        duration: audioBuffer.duration,
        sampleRate: audioBuffer.sampleRate,
      };
      this.audioPeaksCache.set(cacheKey, result);
      return result;
    } catch {
      const fallbackPeaks = new Float32Array(numBuckets);
      for (let i = 0; i < numBuckets; i++) {
        fallbackPeaks[i] = 0.2 + 0.6 * Math.abs(Math.sin((i / 8) * Math.PI));
      }
      const fallbackResult: CachedAudioPeaks = {
        peaks: fallbackPeaks,
        duration: 10,
        sampleRate: 44100,
      };
      this.audioPeaksCache.set(cacheKey, fallbackResult);
      return fallbackResult;
    }
  }

  getAudioPeaks(cacheKey: string): CachedAudioPeaks | null {
    return this.audioPeaksCache.get(cacheKey) || null;
  }

  cleanup(clipId: string) {
    if (this.videoBlobUrlCache.has(clipId)) {
      URL.revokeObjectURL(this.videoBlobUrlCache.get(clipId)!);
      this.videoBlobUrlCache.delete(clipId);
    }
    const el = this.videoElementPool.get(clipId);
    if (el) {
      try {
        el.pause();
        el.removeAttribute('src');
        el.load();
        el.remove();
      } catch (_) {}
      this.videoElementPool.delete(clipId);
    }
  }
}

export const assetCache = new AssetCacheService();
