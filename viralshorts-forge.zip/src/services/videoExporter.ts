export class BrowserVideoExporter {
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];

  startRecordingCanvas(
    canvas: HTMLCanvasElement,
    audioStream?: MediaStream,
    fps: number = 60
  ): void {
    this.recordedChunks = [];
    const canvasStream = canvas.captureStream(fps);

    if (audioStream) {
      audioStream.getAudioTracks().forEach((track) => {
        canvasStream.addTrack(track);
      });
    }

    const mimeType = MediaRecorder.isTypeSupported('video/mp4;codecs=avc1')
      ? 'video/mp4;codecs=avc1'
      : MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
      ? 'video/webm;codecs=vp9'
      : 'video/webm';

    this.mediaRecorder = new MediaRecorder(canvasStream, {
      mimeType,
      videoBitsPerSecond: 12_000_000,
    });

    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        this.recordedChunks.push(event.data);
      }
    };

    this.mediaRecorder.start(100);
  }

  stopAndDownload(filename: string = 'the-forge-master-cut'): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        reject(new Error('Recorder is not active.'));
        return;
      }

      this.mediaRecorder.onstop = () => {
        const mimeType = this.mediaRecorder?.mimeType || 'video/webm';
        const extension = mimeType.includes('mp4') ? 'mp4' : 'webm';
        const finalBlob = new Blob(this.recordedChunks, { type: mimeType });
        const downloadUrl = URL.createObjectURL(finalBlob);

        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = `${filename}.${extension}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        resolve(downloadUrl);
      };

      this.mediaRecorder.stop();
    });
  }
}

export const videoExporter = new BrowserVideoExporter();
