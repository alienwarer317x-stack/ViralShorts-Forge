import { TimelineClip } from '../types';
import { assetCache } from './assetCache';

export type FreeProviderMode = 'auto_smart' | 'huggingface_wan_video' | 'pollinations_flux_motion';

export function getFreePollinationsImageUrl(
  prompt: string,
  width: number = 720,
  height: number = 1280,
  seed: number = Math.floor(Math.random() * 100000)
): string {
  const encodedPrompt = encodeURIComponent(
    `${prompt}, cinematic lighting, 35mm film still, photorealistic, 8k, masterpiece`
  );
  return `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${width}&height=${height}&seed=${seed}&model=flux&nologo=true`;
}

export async function generateFreeHuggingFaceVideo(
  prompt: string,
  hfUserToken?: string
): Promise<string> {
  const { Client } = await import('@gradio/client');
  const client = await Client.connect('Wan-AI/Wan2.1', hfUserToken ? { hf_token: hfUserToken as `hf_${string}` } : undefined);
  const result = await client.predict('/t2v_generation', {
    prompt: `${prompt}, cinematic camera motion, high detail`,
    size: '832*480',
    watermark_wan: false,
    seed: -1,
  });
  const videoData = (result.data as Array<{ video?: { url?: string }; url?: string }>)[0];
  const remoteUrl = videoData?.video?.url || videoData?.url;
  if (!remoteUrl) {
    throw new Error('Hugging Face free GPU queue is currently full.');
  }
  const response = await fetch(remoteUrl);
  const blob = await response.blob();
  return blobToBase64(blob);
}

export async function generateFreeAnimatedFluxVideoClip(
  prompt: string,
  aspectRatio: '16:9' | '9:16' = '9:16',
  durationSec: number = 5
): Promise<{ base64: string; mimeType: string }> {
  const width = aspectRatio === '9:16' ? 720 : 1280;
  const height = aspectRatio === '9:16' ? 1280 : 720;
  const imageUrl = getFreePollinationsImageUrl(prompt, width, height);

  const img = new Image();
  img.crossOrigin = 'anonymous';
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error('Failed to load free Pollinations AI image'));
    img.src = imageUrl;
  });

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  const stream = canvas.captureStream(30);
  const mimeType = MediaRecorder.isTypeSupported('video/mp4;codecs=avc1')
    ? 'video/mp4;codecs=avc1'
    : 'video/webm';

  const recorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: 6_000_000,
  });

  const chunks: Blob[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };

  recorder.start();

  const fps = 30;
  const totalFrames = durationSec * fps;

  for (let frame = 0; frame < totalFrames; frame++) {
    const progress = frame / totalFrames;
    const scale = 1.0 + progress * 0.14;
    const drawW = width * scale;
    const drawH = height * scale;
    const offsetX = (width - drawW) / 2;
    const offsetY = (height - drawH) / 2;

    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(img, offsetX, offsetY, drawW, drawH);

    await new Promise((r) => setTimeout(r, 1000 / fps));
  }

  recorder.stop();

  const finalBlob = await new Promise<Blob>((resolve) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType }));
  });

  const base64 = await blobToBase64(finalBlob);
  return { base64, mimeType };
}

export async function generateFreeSceneForTimeline(
  prompt: string,
  aspectRatio: '16:9' | '9:16' = '9:16',
  startSec: number = 0,
  durationSec: number = 5,
  mode: FreeProviderMode = 'auto_smart',
  hfUserToken?: string
): Promise<TimelineClip> {
  const clipId = `clip-v1-${Date.now()}`;
  let base64 = '';
  let mimeType = 'video/mp4';

  if (mode === 'huggingface_wan_video' || mode === 'auto_smart') {
    try {
      base64 = await generateFreeHuggingFaceVideo(prompt, hfUserToken);
      mimeType = 'video/mp4';
    } catch (err) {
      console.warn('Free HF GPU queue busy, switching to instant Pollinations Flux Motion engine:', err);
      const fallback = await generateFreeAnimatedFluxVideoClip(prompt, aspectRatio, durationSec);
      base64 = fallback.base64;
      mimeType = fallback.mimeType;
    }
  } else {
    const res = await generateFreeAnimatedFluxVideoClip(prompt, aspectRatio, durationSec);
    base64 = res.base64;
    mimeType = res.mimeType;
  }

  await assetCache.prewarmVideoElement(clipId, base64, mimeType);

  return {
    id: clipId,
    trackId: 'v1',
    trackType: 'video',
    name: prompt.slice(0, 22) || 'AI Scene',
    startSec,
    durationSec,
    trimInSec: 0,
    color: '#ec4899',
    base64,
    mimeType,
    speed: 1.0,
    volume: 1.0,
  };
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const dataUrl = reader.result as string;
      resolve(dataUrl.split(',')[1] || '');
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
