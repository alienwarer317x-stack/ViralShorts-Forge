import React from 'react';
import { TimelineClip, TimelineTrack } from '../types';

interface TimelineProps {
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  currentTime: number;
  totalDurationSec: number;
  zoomLevel: number;
  selectedClipId: string | null;
  onSelectClip: (clip: TimelineClip | null) => void;
  onSeek: (time: number) => void;
  onMoveClip: (clipId: string, newStart: number) => void;
}

export const Timeline: React.FC<TimelineProps> = ({
  tracks,
  clips,
  currentTime,
  totalDurationSec,
  zoomLevel,
  selectedClipId,
  onSelectClip,
  onSeek,
}) => {
  const timelineWidth = Math.max(800, totalDurationSec * zoomLevel);

  return (
    <div className="w-full h-full bg-[#0b0e17] border-t border-slate-800 flex flex-col select-none overflow-hidden">
      <div
        className="h-7 bg-[#0f121d] border-b border-slate-800 flex items-center relative cursor-pointer"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          const newTime = Math.max(0, (clickX - 160) / zoomLevel);
          onSeek(newTime);
        }}
      >
        <div className="w-40 flex-shrink-0 px-3 text-[10px] font-mono text-slate-400 uppercase font-bold border-r border-slate-800 flex items-center justify-between">
          <span>Tracks</span>
          <span className="text-amber-400">{zoomLevel}px/s</span>
        </div>
        <div className="flex-1 relative overflow-hidden h-full">
          <div className="absolute inset-0" style={{ width: `${timelineWidth}px` }}>
            {Array.from({ length: Math.ceil(totalDurationSec) + 1 }).map((_, sec) => (
              <div
                key={sec}
                className="absolute top-0 bottom-0 border-l border-slate-800/80 text-[9px] font-mono text-slate-500 pl-1 pt-1"
                style={{ left: `${sec * zoomLevel}px` }}
              >
                {sec % 5 === 0 ? `${sec}s` : ''}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-auto relative">
        <div style={{ width: `${timelineWidth + 160}px` }} className="flex flex-col">
          {tracks.map((track) => {
            const trackClips = clips.filter((c) => c.trackId === track.id);
            return (
              <div
                key={track.id}
                className="flex items-center border-b border-slate-800/60 bg-[#0d101a] hover:bg-[#111524] transition-colors"
                style={{ height: `${track.heightPx}px` }}
              >
                <div className="w-40 flex-shrink-0 px-3 flex items-center justify-between border-r border-slate-800 bg-[#0a0c14] z-10 sticky left-0">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={`w-2 h-2 rounded-full ${track.type === 'video' ? 'bg-cyan-400' : track.type === 'audio' ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                    <span className="text-xs font-mono font-bold text-slate-200 truncate uppercase">{track.name}</span>
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 uppercase">{track.id}</span>
                </div>

                <div className="flex-1 relative h-full">
                  {trackClips.map((clip) => {
                    const isSelected = clip.id === selectedClipId;
                    const leftPx = clip.startSec * zoomLevel;
                    const widthPx = clip.durationSec * zoomLevel;

                    return (
                      <div
                        key={clip.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectClip(clip);
                        }}
                        className={`absolute top-1 bottom-1 rounded-lg border px-2.5 py-1 flex flex-col justify-center cursor-pointer transition-all shadow-md overflow-hidden ${
                          isSelected
                            ? 'border-amber-400 bg-amber-950/80 text-white shadow-amber-500/20 ring-1 ring-amber-400'
                            : 'border-slate-700/80 bg-slate-900/90 text-slate-200 hover:border-slate-500'
                        }`}
                        style={{ left: `${leftPx}px`, width: `${widthPx}px`, backgroundColor: clip.color ? `${clip.color}33` : undefined }}
                      >
                        <span className="text-[11px] font-mono font-bold truncate">{clip.name}</span>
                        <span className="text-[9px] font-mono text-slate-400">{clip.durationSec.toFixed(1)}s</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        <div
          className="absolute top-0 bottom-0 w-0.5 bg-rose-500 z-30 pointer-events-none"
          style={{ left: `${currentTime * zoomLevel + 160}px` }}
        >
          <div className="w-3 h-3 bg-rose-500 rotate-45 -translate-x-1.5 -translate-y-1 shadow-lg" />
        </div>
      </div>
    </div>
  );
};
