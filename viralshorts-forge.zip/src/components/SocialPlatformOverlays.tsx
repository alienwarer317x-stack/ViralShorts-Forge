import React from 'react';
import { StoryboardScene, VideoProject } from '../types';

interface SocialPlatformOverlaysProps {
  platform: 'tiktok' | 'youtube_shorts' | 'instagram_reels' | 'none';
  project: VideoProject;
  activeScene: StoryboardScene;
  showSafeZones: boolean;
  isLandscape: boolean;
}

export const SocialPlatformOverlays: React.FC<SocialPlatformOverlaysProps> = ({
  platform,
  activeScene,
  project,
  showSafeZones,
}) => {
  if (platform === 'none') return null;

  return (
    <div className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-4 font-sans text-white select-none">
      <div className="flex items-center justify-between">
        <div className="bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-mono border border-white/10 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="uppercase font-bold tracking-wider">{platform.replace('_', ' ')} HUD</span>
        </div>
        {showSafeZones && (
          <div className="bg-amber-500/80 text-black px-2 py-0.5 rounded text-[9px] font-mono font-bold">
            SAFE ZONE ACTIVE
          </div>
        )}
      </div>

      <div className="absolute right-3 bottom-24 flex flex-col items-center gap-4 text-white">
        <div className="flex flex-col items-center gap-1">
          <div className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-md border border-white/20 flex items-center justify-center">
            <span className="material-symbols-outlined text-[20px]">favorite</span>
          </div>
          <span className="text-[10px] font-mono font-bold">128.4K</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <div className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-md border border-white/20 flex items-center justify-center">
            <span className="material-symbols-outlined text-[20px]">mode_comment</span>
          </div>
          <span className="text-[10px] font-mono font-bold">1,420</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <div className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-md border border-white/20 flex items-center justify-center">
            <span className="material-symbols-outlined text-[20px]">share</span>
          </div>
          <span className="text-[10px] font-mono font-bold">8.5K</span>
        </div>
      </div>

      <div className="flex flex-col gap-1.5 max-w-[75%] pb-2">
        <span className="font-bold text-xs drop-shadow-md">@{project?.title?.toLowerCase().replace(/\s+/g, '') || 'viralshorts'}</span>
        <p className="text-[11px] leading-snug text-slate-200 line-clamp-2 drop-shadow-md">
          {activeScene?.narration || activeScene?.title} #{activeScene?.hookKeywords?.[0] || 'trending'} #theforge
        </p>
        <div className="flex items-center gap-2 text-[10px] font-mono text-slate-300">
          <span className="material-symbols-outlined text-[13px] animate-spin">music_note</span>
          <span className="truncate">Original Sound - The Forge Studio Master</span>
        </div>
      </div>
    </div>
  );
};
