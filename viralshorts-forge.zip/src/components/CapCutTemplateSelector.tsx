import React from 'react';
import { CapCutTemplateConfig, CapCutTemplateType, SocialFramePreset, VideoFormat } from '../types';
import { CAPCUT_TEMPLATES_LIST } from '../constants';

interface CapCutTemplateSelectorProps {
  config: CapCutTemplateConfig;
  onChangeConfig: (patch: Partial<CapCutTemplateConfig>) => void;
  selectedFormat: VideoFormat;
  onSelectFormat: (format: VideoFormat) => void;
  onQuickGenerateWithTemplate?: (templateId: CapCutTemplateType) => void;
}

export const CapCutTemplateSelector: React.FC<CapCutTemplateSelectorProps> = ({
  config,
  onChangeConfig,
  selectedFormat,
  onSelectFormat,
  onQuickGenerateWithTemplate,
}) => {
  const activeTemplate = CAPCUT_TEMPLATES_LIST.find((t) => t.id === config.templateId) || CAPCUT_TEMPLATES_LIST[0];
  const socialFrames: Array<{
    id: SocialFramePreset;
    label: string;
    ratio: VideoFormat;
    icon: string;
    desc: string;
    badge: string;
  }> = [
    {
      id: 'tiktok',
      label: 'TikTok Frame (9:16)',
      ratio: '9:16',
      icon: 'bolt',
      desc: 'Real UI overlay: profile avatar, like button, comment bubble, sound disc, safe margin grid',
      badge: 'CapCut Default',
    },
    {
      id: 'youtube_shorts',
      label: 'YouTube Shorts (9:16)',
      ratio: '9:16',
      icon: 'smart_display',
      desc: 'Subscribe pill, thumbs up counters, channel handle, remix button HUD',
      badge: 'Shorts Native',
    },
    {
      id: 'instagram_reels',
      label: 'Instagram Reels (9:16 / 1:1)',
      ratio: '9:16',
      icon: 'photo_camera',
      desc: 'Reels audio waves, explore card tags, like & share floating actions',
      badge: 'Meta Reels',
    },
    {
      id: 'none',
      label: 'Clean Cinema (No HUD)',
      ratio: selectedFormat,
      icon: 'crop_free',
      desc: 'Pure cinematic output without social media overlays or icon obstruction',
      badge: 'Clean Video',
    },
  ];

  return (
    <div className="w-full bg-[#0d0f19] border-2 border-pink-500/50 rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col gap-4 text-white">
      <div className="flex items-center justify-between flex-wrap gap-2.5 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500 via-rose-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-pink-600/30 flex-shrink-0">
            <span className="material-symbols-outlined text-[22px] text-white">auto_awesome_motion</span>
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm sm:text-base font-black uppercase tracking-wider font-mono text-white flex items-center gap-1.5">
                CapCut Template Generator &amp; Social Frame Studio
              </h3>
              <span className="text-[10px] font-mono font-bold bg-pink-950 border border-pink-500 text-pink-300 px-2 py-0.5 rounded-full animate-pulse">
                Template Mode ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5 font-sans leading-snug">
              Generate videos modeled after viral CapCut templates: velocity speed-ramps, beat drop flash cuts, light leaks, and live social media UI frames.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 bg-black/60 px-3 py-1.5 rounded-xl border border-pink-500/40 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={config.enabled}
              onChange={(e) => onChangeConfig({ enabled: e.target.checked })}
              className="w-3.5 h-3.5 rounded text-pink-500 focus:ring-0 cursor-pointer"
            />
            <span className="text-xs font-mono font-bold text-pink-300">
              CapCut Pacing {config.enabled ? 'ON' : 'OFF'}
            </span>
          </label>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-pink-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[15px]">style</span>
            Choose CapCut Video Template Preset ({CAPCUT_TEMPLATES_LIST.length}):
          </span>
          <span className="text-[10px] text-slate-400 font-mono">
            Active: <strong className="text-white">{activeTemplate.title}</strong> &bull; {activeTemplate.bpm} BPM
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {CAPCUT_TEMPLATES_LIST.map((tpl) => {
            const isSelected = config.templateId === tpl.id;
            return (
              <div
                key={tpl.id}
                onClick={() => {
                  onChangeConfig({ 
                    templateId: tpl.id,
                    bpmRate: tpl.bpm,
                  });
                }}
                className={`p-3 rounded-xl border text-left flex flex-col justify-between gap-2 transition-all cursor-pointer group ${
                  isSelected
                    ? 'bg-gradient-to-b from-pink-950/70 to-purple-950/60 border-pink-400 text-white shadow-lg ring-1 ring-pink-500/50'
                    : 'bg-black/50 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-start justify-between gap-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      isSelected ? 'bg-pink-600 text-white shadow-md' : 'bg-slate-800 text-pink-400'
                    }`}>
                      <span className="material-symbols-outlined text-[18px]">{tpl.icon}</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="text-xs font-black font-mono leading-tight truncate text-white">
                        {tpl.title}
                      </span>
                      <span className="text-[9.5px] font-mono text-pink-300 font-bold">
                        {tpl.badge}
                      </span>
                    </div>
                  </div>

                  <span className={`text-[9.5px] font-mono font-bold px-1.5 py-0.5 rounded border whitespace-nowrap ${
                    isSelected ? 'bg-pink-900/60 border-pink-500 text-pink-200' : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}>
                    {tpl.bpm} BPM
                  </span>
                </div>

                <p className="text-[10px] text-slate-300 line-clamp-2 leading-snug">
                  {tpl.tagline}
                </p>

                <div className="text-[9px] font-mono text-cyan-300 bg-black/40 p-1.5 rounded border border-slate-800/80 truncate">
                  ⚡ VFX: {tpl.vfxDescription}
                </div>

                {onQuickGenerateWithTemplate && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onChangeConfig({ templateId: tpl.id });
                      onQuickGenerateWithTemplate(tpl.id);
                    }}
                    className={`mt-1 py-1 px-2 rounded-lg text-[10px] font-mono font-bold transition-all flex items-center justify-center gap-1 cursor-pointer ${
                      isSelected
                        ? 'bg-pink-600 hover:bg-pink-500 text-white shadow'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[12px]">play_arrow</span>
                    <span>Generate With This Template</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex flex-col gap-2 pt-2 border-t border-slate-800">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[15px]">aspect_ratio</span>
            Select Social Media Frame Overlay:
          </span>
          <span className="text-[10px] text-slate-400 font-mono">
            Renders exact native social icons, live reaction counter &amp; safe zone HUD
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {socialFrames.map((frame) => {
            const isSelected = config.socialFrame === frame.id;
            return (
              <button
                key={frame.id}
                onClick={() => {
                  onChangeConfig({ socialFrame: frame.id });
                  if (frame.ratio !== 'none' && frame.id !== 'none') {
                    onSelectFormat(frame.ratio);
                  }
                }}
                className={`p-2.5 rounded-xl border text-left flex flex-col justify-between gap-1.5 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-950/60 border-cyan-400 text-white shadow-md ring-1 ring-cyan-500/50'
                    : 'bg-black/50 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[16px] text-cyan-400">{frame.icon}</span>
                    <span className="text-xs font-bold font-mono text-white">{frame.label}</span>
                  </div>
                  {isSelected && (
                    <span className="material-symbols-outlined text-[14px] text-cyan-400">check_circle</span>
                  )}
                </div>

                <p className="text-[9.5px] text-slate-400 line-clamp-2 leading-tight">
                  {frame.desc}
                </p>

                <div className="flex items-center justify-between text-[9px] font-mono text-cyan-300 pt-1 border-t border-slate-800/60">
                  <span>{frame.badge}</span>
                  <span className="text-slate-500 uppercase">{frame.ratio}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
