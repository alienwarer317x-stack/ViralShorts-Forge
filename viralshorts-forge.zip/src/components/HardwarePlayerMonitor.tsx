import React, { useRef, useEffect, useState } from 'react';
import { TimelineClip, ProjectSettings, FilmAspectGuidance, SocialFramePreset, VideoProject } from '../types';
import { FILM_ASPECT_RATIOS } from '../constants';
import { assetCache } from '../services/assetCache';
import { SocialPlatformOverlays } from './SocialPlatformOverlays';

interface HardwarePlayerMonitorProps {
  currentTime: number;
  totalDurationSec: number;
  isPlaying: boolean;
  activeVideoClip: TimelineClip | null;
  activeTextClips: TimelineClip[];
  settings: ProjectSettings;
  filmAspect?: FilmAspectGuidance;
  onSelectFilmAspect?: (aspect: FilmAspectGuidance) => void;
  cinemascopeLetterbox?: boolean;
  filterClass?: string;
  filmGrainEnabled?: boolean;
  socialFrame?: SocialFramePreset;
  onSelectSocialFrame?: (frame: SocialFramePreset) => void;
  project?: VideoProject;
  onTogglePlay: () => void;
  onSeek: (timeSec: number) => void;
  onStepFrame: (frames: number) => void;
}

export const HardwarePlayerMonitor: React.FC<HardwarePlayerMonitorProps> = ({
  currentTime,
  totalDurationSec,
  isPlaying,
  activeVideoClip,
  activeTextClips,
  settings,
  filmAspect = 'cinemascope_239',
  onSelectFilmAspect,
  cinemascopeLetterbox = true,
  filterClass = '',
  filmGrainEnabled = false,
  socialFrame = 'none',
  onSelectSocialFrame,
  project,
  onTogglePlay,
  onSeek,
  onStepFrame,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hiddenVideoRef = useRef<HTMLVideoElement>(null);
  const rafIdRef = useRef<number | null>(null);
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [volumeLevel, setVolumeLevel] = useState(1.0);
  const [showSafeZoneGuide] = useState(false);
  const [theaterLightingMode, setTheaterLightingMode] = useState<'dimmed' | 'darkroom' | 'premiere'>('dimmed');

  useEffect(() => {
    if (!activeVideoClip?.base64) return;
    assetCache.prewarmVideoElement(
      activeVideoClip.id,
      activeVideoClip.base64,
      activeVideoClip.mimeType || 'video/mp4'
    );
  }, [activeVideoClip]);

  useEffect(() => {
    const video = hiddenVideoRef.current;
    if (!video) return;
    if (activeVideoClip?.base64) {
      const url = assetCache.getOrCreateVideoUrl(
        activeVideoClip.id,
        activeVideoClip.base64,
        activeVideoClip.mimeType || 'video/mp4'
      );
      if (video.src !== url) {
        video.src = url;
        video.load();
      }
      const offsetInClip = (currentTime - activeVideoClip.startSec) + (activeVideoClip.trimInSec || 0);
      const clampedOffset = Math.max(0, offsetInClip);
      if (Math.abs(video.currentTime - clampedOffset) > 0.08) {
        try {
          video.currentTime = clampedOffset;
        } catch (_) {}
      }
      video.muted = isAudioMuted;
      video.volume = volumeLevel;
      if (isPlaying && video.paused) {
        video.play().catch(() => {
          video.muted = true;
          video.play().catch(() => {});
        });
      } else if (!isPlaying && !video.paused) {
        video.pause();
      }
    } else {
      if (!video.paused) {
        video.pause();
      }
    }
  }, [currentTime, isPlaying, activeVideoClip, isAudioMuted, volumeLevel]);

  const getCanvasDimensions = () => {
    if (socialFrame === 'tiktok' || socialFrame === 'youtube_shorts' || socialFrame === 'instagram_reels') {
      return { width: 720, height: 1280 };
    }
    switch (filmAspect) {
      case 'cinemascope_239':
        return { width: 1720, height: 720 };
      case 'anamorphic_200':
        return { width: 1440, height: 720 };
      case 'academy_185':
        return { width: 1332, height: 720 };
      case 'imax_vertical_916':
        return { width: 720, height: 1280 };
      case 'full_frame_169':
      default:
        return { width: 1280, height: 720 };
    }
  };

  const activeAspectConfig = FILM_ASPECT_RATIOS.find((a) => a.id === filmAspect) || FILM_ASPECT_RATIOS[0];
  const { width: canvasW, height: canvasH } = getCanvasDimensions();

  const activeSceneSegment = project?.scenes.find(
    (s) => s.id === (activeVideoClip?.id?.replace('clip-v1-', '') || '')
  ) || project?.scenes[0] || {
    id: 'placeholder',
    order: 1,
    duration: 6,
    title: 'Theatrical Master Shot',
    storyBeat: 'Cinema hall projection',
    visualDescription: '',
    continuityFromPrevious: '',
    narration: project?.topic || 'Theatrical movie hall scene preview',
    visualPrompt: '',
    animationPrompt: '',
    caption: 'NOW SHOWING',
    hookKeywords: ['cinema', 'moviehall', 'theatrical'],
    status: 'ready' as const,
  };

  const isVerticalView = settings.aspectRatio === '9:16' || socialFrame !== 'none';

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;
    let isSubscribed = true;

    const renderFrame = () => {
      if (!isSubscribed) return;
      const video = hiddenVideoRef.current;
      const targetW = canvas.width;
      const targetH = canvas.height;

      ctx.fillStyle = '#020306';
      ctx.fillRect(0, 0, targetW, targetH);

      if (video && video.readyState >= 2 && activeVideoClip?.base64) {
        const vW = video.videoWidth || 1280;
        const vH = video.videoHeight || 720;
        const ratio = Math.min(targetW / vW, targetH / vH);
        const drawW = vW * ratio;
        const drawH = vH * ratio;
        const x = (targetW - drawW) / 2;
        const y = (targetH - drawH) / 2;
        ctx.drawImage(video, x, y, drawW, drawH);
      } else {
        ctx.fillStyle = '#060810';
        ctx.fillRect(0, 0, targetW, targetH);

        const beamGrad = ctx.createRadialGradient(
          targetW / 2, targetH / 2, targetW * 0.05,
          targetW / 2, targetH / 2, targetW * 0.55
        );
        beamGrad.addColorStop(0, 'rgba(245, 158, 11, 0.06)');
        beamGrad.addColorStop(1, 'rgba(0, 0, 0, 0.85)');
        ctx.fillStyle = beamGrad;
        ctx.fillRect(0, 0, targetW, targetH);

        ctx.strokeStyle = '#1e2436';
        ctx.lineWidth = 1;
        ctx.strokeRect(40, 28, targetW - 80, targetH - 56);

        ctx.strokeStyle = '#334155';
        ctx.beginPath();
        ctx.moveTo(targetW / 2 - 16, targetH / 2);
        ctx.lineTo(targetW / 2 + 16, targetH / 2);
        ctx.moveTo(targetW / 2, targetH / 2 - 16);
        ctx.lineTo(targetW / 2, targetH / 2 + 16);
        ctx.stroke();

        ctx.fillStyle = '#f8fafc';
        ctx.font = '900 16px "Inter", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(
          activeVideoClip ? activeVideoClip.name.toUpperCase() : 'THEATRICAL SCREENING AUDITORIUM',
          targetW / 2,
          targetH / 2 - 12
        );

        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 11px monospace';
        ctx.fillText(
          activeVideoClip
            ? 'AUDIO / VIDEO DIRECT DECODING ACTIVE • 60 FPS'
            : 'READY FOR PLAYBACK • PRESS PLAY OR POSITION TIMELINE PLAYHEAD',
          targetW / 2,
          targetH / 2 + 16
        );

        ctx.fillStyle = '#f59e0b';
        ctx.font = 'bold 9px monospace';
        ctx.fillText('STAGE MONITOR // DOLBY ATMOS OPTICAL APERTURE // DCI 4K', targetW / 2, targetH / 2 + 36);
      }

      if (filmGrainEnabled) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.032)';
        for (let i = 0; i < 280; i++) {
          const gx = Math.random() * targetW;
          const gy = Math.random() * targetH;
          ctx.fillRect(gx, gy, 1.5, 1.5);
        }
      }

      rafIdRef.current = requestAnimationFrame(renderFrame);
    };

    rafIdRef.current = requestAnimationFrame(renderFrame);
    return () => {
      isSubscribed = false;
      if (rafIdRef.current) cancelAnimationFrame(rafIdRef.current);
    };
  }, [activeVideoClip, filmGrainEnabled, canvasW, canvasH]);

  const formatTimecode = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    const frames = Math.floor((sec % 1) * settings.fps);
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}:${frames < 10 ? '0' : ''}${frames}`;
  };

  const getAspectClass = () => {
    if (socialFrame === 'tiktok' || socialFrame === 'youtube_shorts' || socialFrame === 'instagram_reels') {
      return 'w-[260px] sm:w-[290px] aspect-[9/16]';
    }
    switch (filmAspect) {
      case 'cinemascope_239':
        return 'w-full max-w-[860px] aspect-[2.39/1]';
      case 'anamorphic_200':
        return 'w-full max-w-[800px] aspect-[2/1]';
      case 'academy_185':
        return 'w-full max-w-[760px] aspect-[1.85/1]';
      case 'imax_vertical_916':
        return 'w-[260px] sm:w-[290px] aspect-[9/16]';
      case 'full_frame_169':
      default:
        return 'w-full max-w-[760px] aspect-video';
    }
  };

  return (
    <div className="w-full flex flex-col items-center justify-between h-full bg-[#05060b] p-2 sm:p-4 gap-3 select-none min-w-0">
      <video
        ref={hiddenVideoRef}
        playsInline
        preload="auto"
        className="opacity-0 pointer-events-none absolute w-0 h-0"
      />

      <div className="w-full max-w-[900px] bg-gradient-to-r from-[#0d0f1a] via-[#12162a] to-[#0d0f1a] border border-amber-500/40 rounded-2xl px-3.5 py-2.5 flex items-center justify-between flex-wrap gap-2.5 text-xs font-mono shadow-xl">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-600 to-amber-700 flex items-center justify-center text-black font-black shadow-md flex-shrink-0">
            <span className="material-symbols-outlined text-[19px] text-black">theaters</span>
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-xs tracking-wider uppercase truncate">
                Movie Hall Cinema Screen
              </span>
              <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-amber-950 border border-amber-500/80 text-amber-300">
                AUDITORIUM 1 &bull; {activeAspectConfig.ratioLabel}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 truncate">
              {activeAspectConfig.name} &bull; DCI Master Prime Optics &bull; Stage Matte Active
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-black/70 p-1 rounded-xl border border-slate-800 text-[10px]">
            <span className="text-slate-500 px-1 font-bold">AMBIENCE:</span>
            {[
              { id: 'dimmed' as const, label: 'Hall Lights' },
              { id: 'darkroom' as const, label: 'Darkroom' },
              { id: 'premiere' as const, label: 'Glow' },
            ].map((mode) => (
              <button
                key={mode.id}
                onClick={() => setTheaterLightingMode(mode.id)}
                className={`px-2 py-0.5 rounded transition-all cursor-pointer font-bold ${
                  theaterLightingMode === mode.id
                    ? 'bg-amber-500 text-black shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {mode.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 bg-black/70 p-1 rounded-xl border border-amber-500/30">
            {FILM_ASPECT_RATIOS.map((ratio) => (
              <button
                key={ratio.id}
                onClick={() => {
                  onSelectFilmAspect?.(ratio.id);
                  if (socialFrame !== 'none') {
                    onSelectSocialFrame?.('none');
                  }
                }}
                className={`px-2.5 py-1 rounded-lg text-[10.5px] font-bold font-mono transition-all cursor-pointer ${
                  filmAspect === ratio.id && socialFrame === 'none'
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
                title={ratio.name}
              >
                {ratio.ratioLabel}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className={`relative w-full max-w-[900px] rounded-3xl p-3 sm:p-6 flex flex-col items-center justify-center transition-all duration-500 ${
        theaterLightingMode === 'premiere'
          ? 'bg-gradient-to-b from-[#130d22] via-[#090b14] to-[#040508] shadow-[0_0_120px_rgba(245,158,11,0.18)]'
          : theaterLightingMode === 'dimmed'
          ? 'bg-gradient-to-b from-[#14121a] via-[#080910] to-[#030408] shadow-[0_0_80px_rgba(0,0,0,0.9)]'
          : 'bg-[#020205] shadow-[0_0_90px_rgba(0,0,0,0.99)]'
      } border-2 border-slate-800/80`}>
        
        <div className="w-full flex items-center justify-between px-4 pb-2 text-[10px] font-mono text-slate-500 border-b border-white/5 select-none">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
            <span className="text-amber-400 font-bold">PROJECTOR: 4K LASER HDR</span>
            <span>&bull;</span>
            <span className="text-slate-400">AUDIO CH: 7.1.4 DOLBY ATMOS</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-slate-400">{formatTimecode(currentTime)} / {formatTimecode(totalDurationSec)}</span>
            <div className="flex items-center gap-1 bg-black/60 px-2 py-0.5 rounded border border-slate-800 text-emerald-400 font-bold">
              <span className="material-symbols-outlined text-[13px]">volume_up</span>
              <span>{isAudioMuted ? 'MUTED' : `${Math.round(volumeLevel * 100)}%`}</span>
            </div>
          </div>
        </div>

        <div className="w-full flex items-center justify-between py-2 sm:py-3 px-1 sm:px-2 relative">
          <div className="hidden md:flex flex-col items-center gap-2 text-amber-500/40 select-none mr-2">
            <div className="w-2 h-8 rounded bg-gradient-to-b from-amber-400/40 via-amber-500/20 to-transparent shadow-[0_0_15px_rgba(245,158,11,0.3)]" />
            <div className="w-1 h-32 bg-slate-800/40 rounded-full" />
          </div>

          <div className="flex-1 flex flex-col items-center justify-center min-w-0">
            <div className="relative group w-full flex items-center justify-center">
              <div
                className={`relative overflow-hidden rounded-2xl bg-[#010103] border-4 sm:border-[6px] border-[#181a24] shadow-[0_20px_60px_rgba(0,0,0,0.98),0_0_30px_rgba(245,158,11,0.08)] flex items-center justify-center transition-all duration-300 ${getAspectClass()}`}
              >
                {theaterLightingMode === 'premiere' && (
                  <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/10 via-transparent to-rose-500/10 pointer-events-none z-10" />
                )}

                {cinemascopeLetterbox && socialFrame === 'none' && filmAspect !== 'imax_vertical_916' && (
                  <>
                    <div className="absolute top-0 inset-x-0 h-4 sm:h-6 md:h-7 bg-black z-25 pointer-events-none border-b border-white/10 flex items-center justify-between px-3 text-[9px] font-mono text-amber-500/80 shadow-md">
                      <span className="flex items-center gap-1 font-bold">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                        THEATRICAL APERTURE // {activeAspectConfig.name}
                      </span>
                      <span className="text-slate-400">STAGE SAFE 90%</span>
                    </div>

                    <div className="absolute bottom-0 inset-x-0 h-4 sm:h-6 md:h-7 bg-black z-25 pointer-events-none border-t border-white/10 flex items-center justify-between px-3 text-[9px] font-mono text-slate-500 shadow-md">
                      <span>THEATER MONITORING</span>
                      <span className="text-amber-400/90 font-bold">{settings.resolution} &bull; 60 FPS</span>
                    </div>
                  </>
                )}

                <canvas
                  ref={canvasRef}
                  width={canvasW}
                  height={canvasH}
                  className={`w-full h-full object-contain ${filterClass}`}
                />

                {project && socialFrame !== 'none' && (
                  <SocialPlatformOverlays
                    platform={socialFrame === 'tiktok' ? 'tiktok' : socialFrame === 'youtube_shorts' ? 'youtube_shorts' : 'none'}
                    project={project}
                    activeScene={activeSceneSegment}
                    showSafeZones={showSafeZoneGuide}
                    isLandscape={!isVerticalView}
                  />
                )}

                {activeTextClips.map((t) => (
                  <div
                    key={t.id}
                    className="absolute bottom-8 inset-x-4 flex justify-center pointer-events-none z-30"
                  >
                    <div
                      style={{
                        fontSize: `${t.fontSize || 16}px`,
                        color: t.textColor || '#ffffff',
                        backgroundColor: t.textBgColor || 'rgba(0,0,0,0.75)',
                      }}
                      className="px-3.5 py-1.5 rounded-xl font-bold uppercase tracking-wide shadow-2xl border border-white/20 text-center max-w-[90%] break-words"
                    >
                      {t.text || 'Theatrical Subtitle'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full max-w-[720px] h-3 bg-gradient-to-b from-[#181a24] to-transparent rounded-full mt-1.5 opacity-60 pointer-events-none" />
          </div>

          <div className="hidden md:flex flex-col items-center gap-2 text-amber-500/40 select-none ml-2">
            <div className="w-2 h-8 rounded bg-gradient-to-b from-amber-400/40 via-amber-500/20 to-transparent shadow-[0_0_15px_rgba(245,158,11,0.3)]" />
            <div className="w-1 h-32 bg-slate-800/40 rounded-full" />
          </div>
        </div>

        <div className="w-full max-w-[840px] flex items-center justify-between gap-3 pt-2.5 border-t border-slate-800/80 text-xs font-mono flex-wrap">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onSeek(0)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              title="Jump to Start (Home)"
            >
              <span className="material-symbols-outlined text-[18px]">first_page</span>
            </button>

            <button
              onClick={() => onStepFrame(-1)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              title="Step 1 Frame Back"
            >
              <span className="material-symbols-outlined text-[18px]">skip_previous</span>
            </button>

            <button
              onClick={onTogglePlay}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-black font-black flex items-center gap-1.5 shadow-lg shadow-amber-600/30 cursor-pointer transition-all active:scale-95"
              title="Play Theatrical Feature"
            >
              <span className="material-symbols-outlined text-[19px] text-black">
                {isPlaying ? 'pause' : 'play_arrow'}
              </span>
              <span>{isPlaying ? 'Pause Screen' : 'Play Theater Screen'}</span>
            </button>

            <button
              onClick={() => onStepFrame(1)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              title="Step 1 Frame Forward"
            >
              <span className="material-symbols-outlined text-[18px]">skip_next</span>
            </button>

            <button
              onClick={() => onSeek(totalDurationSec)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              title="Jump to End"
            >
              <span className="material-symbols-outlined text-[18px]">last_page</span>
            </button>
          </div>

          <div className="flex items-center gap-3 flex-1 max-w-[360px]">
            <div className="flex items-center gap-1.5 w-28">
              <button
                onClick={() => setIsAudioMuted(!isAudioMuted)}
                className="text-slate-400 hover:text-white"
                title={isAudioMuted ? 'Unmute' : 'Mute'}
              >
                <span className="material-symbols-outlined text-[16px] text-amber-400">
                  {isAudioMuted ? 'volume_off' : 'volume_up'}
                </span>
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={volumeLevel}
                onChange={(e) => setVolumeLevel(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                title="Auditorium volume"
              />
            </div>
            <input
              type="range"
              min="0"
              max={Math.max(1, totalDurationSec)}
              step="0.05"
              value={currentTime}
              onChange={(e) => onSeek(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
              title="Scrub movie hall playhead"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
