import React from 'react';
import { TimelineClip } from '../types';

interface InspectorPanelProps {
  selectedClip: TimelineClip | null;
  onUpdateClip: (patch: Partial<TimelineClip>) => void;
  onDeleteClip: (clipId: string) => void;
}

export const InspectorPanel: React.FC<InspectorPanelProps> = ({
  selectedClip,
  onUpdateClip,
  onDeleteClip,
}) => {
  if (!selectedClip) {
    return (
      <div className="w-72 bg-[#0d0f19] border-l border-slate-800 p-4 flex flex-col items-center justify-center text-center text-slate-500 font-mono text-xs select-none">
        <span className="material-symbols-outlined text-[32px] text-slate-600 mb-2">tune</span>
        <span>Select any clip on the timeline to inspect and edit its properties.</span>
      </div>
    );
  }

  return (
    <div className="w-72 bg-[#0d0f19] border-l border-slate-800 p-4 flex flex-col gap-4 text-white font-mono text-xs select-none overflow-y-auto">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: selectedClip.color }} />
          <span className="font-bold uppercase tracking-wider truncate text-amber-400">{selectedClip.name}</span>
        </div>
        <button
          onClick={() => onDeleteClip(selectedClip.id)}
          className="p-1 rounded-lg text-rose-400 hover:bg-rose-950/60 cursor-pointer"
          title="Delete Clip"
        >
          <span className="material-symbols-outlined text-[16px]">delete</span>
        </button>
      </div>

      <div className="flex flex-col gap-3">
        <div className="flex flex-col gap-1">
          <span className="text-slate-400 text-[10px]">Clip Title</span>
          <input
            type="text"
            value={selectedClip.name}
            onChange={(e) => onUpdateClip({ name: e.target.value })}
            className="bg-black/60 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs focus:border-amber-500 outline-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="flex flex-col gap-1">
            <span className="text-slate-400 text-[10px]">Start Time (s)</span>
            <input
              type="number"
              step="0.1"
              value={selectedClip.startSec}
              onChange={(e) => onUpdateClip({ startSec: Math.max(0, parseFloat(e.target.value) || 0) })}
              className="bg-black/60 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs focus:border-amber-500 outline-none"
            />
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-slate-400 text-[10px]">Duration (s)</span>
            <input
              type="number"
              step="0.1"
              value={selectedClip.durationSec}
              onChange={(e) => onUpdateClip({ durationSec: Math.max(0.5, parseFloat(e.target.value) || 1) })}
              className="bg-black/60 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs focus:border-amber-500 outline-none"
            />
          </div>
        </div>

        {selectedClip.trackType === 'text' && (
          <div className="flex flex-col gap-2 pt-2 border-t border-slate-800">
            <span className="text-amber-400 font-bold">Subtitle Content</span>
            <textarea
              value={selectedClip.text || ''}
              onChange={(e) => onUpdateClip({ text: e.target.value })}
              rows={3}
              className="bg-black/60 border border-slate-800 rounded-lg p-2 text-white font-sans text-xs focus:border-amber-500 outline-none resize-none"
            />
            <div className="grid grid-cols-2 gap-2">
              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Font Size</span>
                <input
                  type="number"
                  value={selectedClip.fontSize || 16}
                  onChange={(e) => onUpdateClip({ fontSize: parseInt(e.target.value) || 16 })}
                  className="bg-black/60 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono text-xs"
                />
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-slate-400 text-[10px]">Text Color</span>
                <input
                  type="color"
                  value={selectedClip.textColor || '#ffffff'}
                  onChange={(e) => onUpdateClip({ textColor: e.target.value })}
                  className="w-full h-8 bg-black/60 border border-slate-800 rounded-lg cursor-pointer p-1"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
