import React from 'react';

interface ToolbarProps {
  onUndo?: () => void;
  onRedo?: () => void;
  onSplit?: () => void;
  onExport: () => void;
  isExporting?: boolean;
  zoomLevel: number;
  onZoomChange: (newZoom: number) => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  onUndo,
  onRedo,
  onSplit,
  onExport,
  isExporting,
  zoomLevel,
  onZoomChange,
}) => {
  return (
    <div className="w-full bg-[#0d0f19] border-b border-slate-800 px-4 py-2 flex items-center justify-between flex-wrap gap-3 select-none">
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-slate-800">
          <button
            onClick={onUndo}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Undo (Ctrl+Z)"
          >
            <span className="material-symbols-outlined text-[18px]">undo</span>
          </button>
          <button
            onClick={onRedo}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Redo (Ctrl+Y)"
          >
            <span className="material-symbols-outlined text-[18px]">redo</span>
          </button>
        </div>

        <div className="h-6 w-px bg-slate-800 mx-1" />

        <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-slate-800">
          <button
            onClick={onSplit}
            className="px-3 py-1.5 rounded-lg text-xs font-mono font-bold text-slate-300 hover:text-white hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
            title="Razor Split at Playhead (S)"
          >
            <span className="material-symbols-outlined text-[16px] text-amber-400">content_cut</span>
            <span>Split (S)</span>
          </button>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono">
          <span className="text-slate-400">Zoom:</span>
          <input
            type="range"
            min="20"
            max="120"
            value={zoomLevel}
            onChange={(e) => onZoomChange(Number(e.target.value))}
            className="w-24 accent-amber-500 cursor-pointer"
          />
          <span className="text-amber-400 font-bold">{zoomLevel}px/s</span>
        </div>

        <button
          onClick={onExport}
          disabled={isExporting}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-600 hover:from-emerald-400 hover:to-cyan-500 text-black font-black text-xs font-mono flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
        >
          <span className="material-symbols-outlined text-[18px] text-black">
            {isExporting ? 'progress_activity' : 'download'}
          </span>
          <span>{isExporting ? 'Rendering Master MP4...' : 'Export Master Cut'}</span>
        </button>
      </div>
    </div>
  );
};
