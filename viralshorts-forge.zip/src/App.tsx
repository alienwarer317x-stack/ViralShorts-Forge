import { useState, useRef } from 'react';
import { TimelineClip, TimelineTrack, ProjectSettings, FilmAspectGuidance, SocialFramePreset, VideoProject, CapCutTemplateConfig } from './types';
import { Toolbar } from './components/Toolbar';
import { InspectorPanel } from './components/InspectorPanel';
import { Timeline } from './components/Timeline';
import { HardwarePlayerMonitor } from './components/HardwarePlayerMonitor';
import { CapCutTemplateSelector } from './components/CapCutTemplateSelector';
import { generateFreeSceneForTimeline } from './services/freeAiProviders';
import { videoExporter } from './services/videoExporter';

export default function App() {
  const [activeTab, setActiveTab] = useState<'workspace' | 'templates' | 'inspector'>('workspace');
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDurationSec] = useState(30);
  const [isPlaying, setIsPlaying] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(40);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [filmAspect, setFilmAspect] = useState<FilmAspectGuidance>('cinemascope_239');
  const [socialFrame, setSocialFrame] = useState<SocialFramePreset>('none');
  const [isExporting, setIsExporting] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('Cinematic drone shot over futuristic neon city at sunset');
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  const [settings] = useState<ProjectSettings>({
    fps: 60,
    resolution: '3840x2160 DCI 4K',
    aspectRatio: '16:9',
  });

  const [project] = useState<VideoProject>({
    id: 'proj-1',
    title: 'The Forge Epic Masterpiece',
    topic: 'Cyberpunk cinematic short-form teaser',
    scenes: [
      {
        id: 'scene-1',
        order: 1,
        duration: 6,
        title: 'Neon Skyline Hook',
        storyBeat: 'Establishing shot',
        visualDescription: 'Cyberpunk Tokyo street at night with neon signs',
        continuityFromPrevious: '',
        narration: 'The future belongs to those who build it.',
        visualPrompt: 'Cyberpunk futuristic neon city',
        animationPrompt: 'Cinematic push in',
        caption: 'THE FUTURE IS HERE',
        hookKeywords: ['future', 'cyberpunk', 'neon'],
        status: 'ready',
      }
    ],
  });

  const [capCutConfig, setCapCutConfig] = useState<CapCutTemplateConfig>({
    enabled: true,
    templateId: 'velocity_ramp',
    socialFrame: 'none',
    beatDropEnabled: true,
    kineticZoom: true,
    lightLeakEffect: true,
    bpmRate: 132,
  });

  const [tracks] = useState<TimelineTrack[]>([
    { id: 'v1', name: 'Video 1', type: 'video', heightPx: 64 },
    { id: 't1', name: 'Subtitles', type: 'text', heightPx: 48 },
    { id: 'a1', name: 'Audio 1', type: 'audio', heightPx: 48 },
  ]);

  const [clips, setClips] = useState<TimelineClip[]>([
    {
      id: 'clip-v1-1',
      trackId: 'v1',
      trackType: 'video',
      name: 'Cyberpunk Opening',
      startSec: 0,
      durationSec: 6,
      trimInSec: 0,
      color: '#06b6d4',
      speed: 1.0,
      volume: 1.0,
    },
    {
      id: 'clip-t1-1',
      trackId: 't1',
      trackType: 'text',
      name: 'Title Subtitle',
      startSec: 0,
      durationSec: 6,
      trimInSec: 0,
      color: '#f59e0b',
      text: 'THE FUTURE IS HERE',
      fontSize: 18,
      textColor: '#ffffff',
      textBgColor: 'rgba(0,0,0,0.8)',
    }
  ]);

  const selectedClip = clips.find((c) => c.id === selectedClipId) || null;
  const activeVideoClip = clips.find((c) => c.trackType === 'video' && currentTime >= c.startSec && currentTime <= c.startSec + c.durationSec) || clips.find((c) => c.trackType === 'video') || null;
  const activeTextClips = clips.filter((c) => c.trackType === 'text' && currentTime >= c.startSec && currentTime <= c.startSec + c.durationSec);

  const handleGenerateAiScene = async () => {
    try {
      setIsGeneratingAi(true);
      const newClip = await generateFreeSceneForTimeline(aiPrompt, settings.aspectRatio, clips.length * 6, 6);
      setClips((prev) => [...prev, newClip]);
      setSelectedClipId(newClip.id);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Generation failed');
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleExportMaster = async () => {
    try {
      setIsExporting(true);
      const canvasEl = document.querySelector('canvas');
      if (!canvasEl) throw new Error('Canvas not found');
      videoExporter.startRecordingCanvas(canvasEl, undefined, settings.fps);
      setCurrentTime(0);
      setIsPlaying(true);
      setTimeout(async () => {
        setIsPlaying(false);
        await videoExporter.stopAndDownload('viralshorts-forge-master-cut');
        setIsExporting(false);
      }, totalDurationSec * 1000);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Export failed');
      setIsExporting(false);
    }
  };

  const playerRef = useRef<HTMLDivElement>(null);

  return (
    <div className="w-screen h-screen flex flex-col bg-[#05060b] text-white overflow-hidden font-sans">
      <header className="h-14 bg-[#0a0d18] border-b border-slate-800 px-4 flex items-center justify-between flex-shrink-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-600 to-rose-600 flex items-center justify-center shadow-lg shadow-amber-600/30">
            <span className="material-symbols-outlined text-[20px] text-black font-black">movie_filter</span>
          </div>
          <div>
            <h1 className="text-sm font-black tracking-wider uppercase font-mono bg-gradient-to-r from-white via-slate-200 to-amber-400 bg-clip-text text-transparent">
              The Forge // Viralshorts NLE
            </h1>
            <span className="text-[10px] font-mono text-slate-400">DCI 4K Theatrical &bull; CapCut Pacing Studio</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {['workspace', 'templates'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as typeof activeTab)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                activeTab === tab
                  ? 'bg-amber-500 text-black shadow-md'
                  : 'bg-black/40 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {tab === 'workspace' ? '🎬 NLE Studio' : '⚡ CapCut Templates'}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="AI scene prompt..."
            className="w-48 sm:w-64 bg-black/60 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:border-amber-500 outline-none"
          />
          <button
            onClick={handleGenerateAiScene}
            disabled={isGeneratingAi}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-black text-xs font-mono shadow-md cursor-pointer transition-all flex items-center gap-1 disabled:opacity-50"
          >
            <span className="material-symbols-outlined text-[15px]">auto_awesome</span>
            <span>{isGeneratingAi ? 'Generating...' : 'Free AI Scene'}</span>
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <div className="flex-1 flex flex-col min-w-0">
          <Toolbar
            onUndo={() => {}}
            onRedo={() => {}}
            onSplit={() => {}}
            onExport={handleExportMaster}
            isExporting={isExporting}
            zoomLevel={zoomLevel}
            onZoomChange={setZoomLevel}
          />

          <div ref={playerRef} className="flex-1 flex flex-col min-h-0 relative">
            {activeTab === 'templates' ? (
              <div className="flex-1 overflow-y-auto p-4 bg-[#060810]">
                <CapCutTemplateSelector
                  config={capCutConfig}
                  onChangeConfig={(patch) => setCapCutConfig((prev) => ({ ...prev, ...patch }))}
                  selectedFormat={settings.aspectRatio}
                  onSelectFormat={(fmt) => setSettings((prev) => ({ ...prev, aspectRatio: fmt }))}
                  onQuickGenerateWithTemplate={() => handleGenerateAiScene()}
                />
              </div>
            ) : (
              <HardwarePlayerMonitor
                currentTime={currentTime}
                totalDurationSec={totalDurationSec}
                isPlaying={isPlaying}
                activeVideoClip={activeVideoClip}
                activeTextClips={activeTextClips}
                settings={settings}
                filmAspect={filmAspect}
                onSelectFilmAspect={setFilmAspect}
                cinemascopeLetterbox={true}
                socialFrame={socialFrame}
                onSelectSocialFrame={setSocialFrame}
                project={project}
                onTogglePlay={() => setIsPlaying(!isPlaying)}
                onSeek={(t) => setCurrentTime(t)}
                onStepFrame={(f) => setCurrentTime((prev) => Math.max(0, prev + f / settings.fps))}
              />
            )}
          </div>

          <div className="h-48 flex-shrink-0">
            <Timeline
              tracks={tracks}
              clips={clips}
              currentTime={currentTime}
              totalDurationSec={totalDurationSec}
              zoomLevel={zoomLevel}
              selectedClipId={selectedClipId}
              onSelectClip={(c) => setSelectedClipId(c?.id || null)}
              onSeek={(t) => setCurrentTime(t)}
              onMoveClip={() => {}}
            />
          </div>
        </div>

        <InspectorPanel
          selectedClip={selectedClip}
          onUpdateClip={(patch) => {
            if (!selectedClipId) return;
            setClips((prev) => prev.map((c) => (c.id === selectedClipId ? { ...c, ...patch } : c)));
          }}
          onDeleteClip={(id) => {
            setClips((prev) => prev.filter((c) => c.id !== id));
            setSelectedClipId(null);
          }}
        />
      </div>
    </div>
  );
}
