import { FilmAspectGuidance, CapCutTemplateType } from './types';

export const FILM_ASPECT_RATIOS: Array<{
  id: FilmAspectGuidance;
  name: string;
  ratioLabel: string;
  description: string;
}> = [
  { id: 'cinemascope_239', name: 'Cinemascope Widescreen', ratioLabel: '2.39:1', description: 'Hollywood theatrical widescreen standard' },
  { id: 'anamorphic_200', name: 'Anamorphic Scope', ratioLabel: '2.00:1', description: 'Modern premium streaming master format' },
  { id: 'academy_185', name: 'Academy Flat', ratioLabel: '1.85:1', description: 'Standard theatrical feature film format' },
  { id: 'full_frame_169', name: 'Full HD Widescreen', ratioLabel: '16:9', description: 'Standard broadcast and YouTube landscape' },
  { id: 'imax_vertical_916', name: 'IMAX / Vertical Shorts', ratioLabel: '9:16', description: 'Immersive vertical mobile format' },
];

export const CAPCUT_TEMPLATES_LIST: Array<{
  id: CapCutTemplateType;
  title: string;
  badge: string;
  bpm: number;
  icon: string;
  tagline: string;
  vfxDescription: string;
}> = [
  { id: 'velocity_ramp', title: 'Velocity Speed-Ramp', badge: 'Viral Trend', bpm: 132, icon: 'speed', tagline: 'Epic high-speed acceleration into slow-motion impact beats.', vfxDescription: '0.2x / 3.5x variable time-mapping' },
  { id: 'beat_drop', title: 'Bass Beat Flash Cuts', badge: 'Music Audio', bpm: 140, icon: 'bolt', tagline: 'Hard flash frame cuts perfectly synchronized to bass drops.', vfxDescription: 'Strobe white flash + 120Hz audio peak slice' },
  { id: 'light_leak', title: '35mm Light Leak Burn', badge: 'Cinematic', bpm: 110, icon: 'lens_blur', tagline: 'Vintage film burn and chromatic aberration light flares.', vfxDescription: 'Warm orange leak overlay & grain' },
  { id: 'cinematic_mood', title: 'Moody Noir Contrast', badge: 'High End', bpm: 95, icon: 'contrast', tagline: 'Rich deep shadows, graded highlights and dramatic timing.', vfxDescription: 'Desaturated shadows & gold highlights' },
  { id: 'glitch_pop', title: 'Cyber Glitch Pop', badge: 'TikTok Hit', bpm: 150, icon: 'electric_bolt', tagline: 'RGB color splitting and digital frame tears on hooks.', vfxDescription: 'RGB shift, scanlines & digital stutter' },
];
